/**
 * <h2>Asciidoclet</h2>
 *
 * https://github.com/asciidoctor/doclet[Asciidoclet] is a Javadoc Doclet
 * that uses http://asciidoctor.org[Asciidoctor] (via the
 * https://github.com/asciidoctor/asciidoctorj[Asciidoctor Java integration])
 * to interpret http://asciidoc.org[AsciiDoc] markup within Javadoc comments.
 *
 * == Usage
 *
 * Asciidoclet may be used via a custom doclet in the maven-javadoc-plugin:
 *
 * <pre>{@code [xml]
 * <plugin>
 *   <groupId>org.apache.maven.plugins</groupId>
 *   <artifactId>maven-javadoc-plugin</artifactId>
 *   <version>2.9</version>
 *   <configuration>
 *     <source>1.7</source>
 *     <doclet>Asciidoclet</doclet>
 *     <docletArtifact>
 *       <groupId>org.doclet</groupId>
 *       <artifactId>doclet</artifactId>
 *       <version>${doclet.version}</version>
 *     </docletArtifact>
 *   </configuration>
 * </plugin>
 * }</pre>
 *
 * <h3>Examples</h3>
 *
 * Code block (with syntax highlighting added by CodeRay)::
 * <pre>{@code [java]
 * /**
 *  * Asciidoclet
 *  *
 *  * A Javadoc Doclet that uses http://asciidoctor.org[Asciidoctor]
 *  * to render http://asciidoc.org[AsciiDoc] markup in Javadoc comments.
 *  *
 *  * @author https://github.com/johncarl81[John Ericksen]
 *  *\/
 * public class Asciidoclet extends Doclet {
 *     private final Asciidoctor asciidoctor = Asciidoctor.Factory.create(); // <1>
 *
 *     @SuppressWarnings("UnusedDeclaration")
 *     public static boolean start(RootDoc rootDoc) {
 *         new Asciidoclet().render(rootDoc); // <2>
 *         return Standard.start(rootDoc);
 *     }
 * }
 * }</pre>
 *
 * @author https://github.com/johncarl81[John Ericksen]
 * @version 0.1.0
 * @see org.avaje.doclet.Asciidoclet
 * @since 0.1.0
 * @serial (or @serialField or @serialData)
 */
package org.avaje.doclet;
