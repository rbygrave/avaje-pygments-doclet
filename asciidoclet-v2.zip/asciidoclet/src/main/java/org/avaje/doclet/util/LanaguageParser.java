package org.avaje.doclet.util;

/**
 * Created by rob on 22/08/14.
 */
public class LanaguageParser {

  final String defaultLanguage;

  public LanaguageParser() {
    this("java");
  }

  public LanaguageParser(String defaultLanguage) {
    this.defaultLanguage = defaultLanguage;
  }

  public String parse(String restOfLine) {

    restOfLine = restOfLine.trim();
    if (restOfLine.startsWith("[") && restOfLine.endsWith("]")) {
      return restOfLine.substring(1, restOfLine.length()-1).toLowerCase();
    }

//    Pattern p = Pattern.compile("class\\s*=\\s*([\"'])?([^ \"']*)");
//    Matcher m = p.matcher(restOfLine);
//    if (m.find()) {
//      String src = m.group(2);
//      src = src.trim();
//      int spacePos = src.indexOf(' ');
//      if (spacePos == -1) {
//        // there is only one word so treat that as the language
//        return src.toLowerCase();
//      } else {
//        // just use the first word
//        return src.substring(0, spacePos-1).toLowerCase();
//      }
//    }

    return defaultLanguage;
  }

}
