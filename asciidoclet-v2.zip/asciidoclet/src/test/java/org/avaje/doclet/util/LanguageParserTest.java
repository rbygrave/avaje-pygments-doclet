package org.avaje.doclet.util;

import org.avaje.doclet.util.LanaguageParser;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by rob on 22/08/14.
 */
public class LanguageParserTest {

  LanaguageParser lanaguageParser = new LanaguageParser();

  @Test
  public void simpleExplicit() {


    Assert.assertEquals("sql", lanaguageParser.parse("[sql]"));
    Assert.assertEquals("sql", lanaguageParser.parse(" [sql]"));
    Assert.assertEquals("sql", lanaguageParser.parse(" [sql] "));
    Assert.assertEquals("sql", lanaguageParser.parse("[SqL]"));
    Assert.assertEquals("java", lanaguageParser.parse(" SqL]"));
    Assert.assertEquals("java", lanaguageParser.parse("[SqL"));
    Assert.assertEquals("xml", lanaguageParser.parse("[XML]"));

  }

}
